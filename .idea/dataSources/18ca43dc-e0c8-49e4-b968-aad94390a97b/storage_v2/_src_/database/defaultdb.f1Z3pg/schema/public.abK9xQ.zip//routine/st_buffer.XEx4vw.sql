create function st_buffer(geography, double precision) returns geography
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT public.geography(public.ST_Transform(public.ST_Buffer(public.ST_Transform(public.geometry($1), public._ST_BestSRID($1)), $2), public.ST_SRID($1)))$$;

alter function st_buffer(geography, double precision) owner to postgres;

