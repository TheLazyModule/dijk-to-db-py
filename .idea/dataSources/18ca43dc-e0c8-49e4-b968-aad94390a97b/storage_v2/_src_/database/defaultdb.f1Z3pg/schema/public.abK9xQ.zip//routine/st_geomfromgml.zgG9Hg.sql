create function st_geomfromgml(text) returns geometry
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$SELECT public._ST_GeomFromGML($1, 0)$$;

alter function st_geomfromgml(text) owner to postgres;

