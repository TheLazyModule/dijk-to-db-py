create function updategeometrysrid(character varying, character varying, integer) returns text
    strict
    language plpgsql
as
$$
DECLARE
	ret  text;
BEGIN
	SELECT public.UpdateGeometrySRID('','',$1,$2,$3) into ret;
	RETURN ret;
END;
$$;

comment on function updategeometrysrid(varchar, varchar, integer) is 'args: table_name, column_name, srid - Updates the SRID of all features in a geometry column, and the table metadata.';

alter function updategeometrysrid(varchar, varchar, integer) owner to postgres;

