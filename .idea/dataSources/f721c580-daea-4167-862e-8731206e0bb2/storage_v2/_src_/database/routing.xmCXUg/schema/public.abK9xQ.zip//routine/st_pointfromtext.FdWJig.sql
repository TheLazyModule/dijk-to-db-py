create function st_pointfromtext(text) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$
	SELECT CASE WHEN public.geometrytype(public.ST_GeomFromText($1)) = 'POINT'
	THEN public.ST_GeomFromText($1)
	ELSE NULL END
	$$;

alter function st_pointfromtext(text) owner to root;

